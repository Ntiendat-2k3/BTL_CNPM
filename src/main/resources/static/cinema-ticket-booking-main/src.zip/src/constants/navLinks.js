export const NAV_LINKS = [
  { to: "/", label: "Movies" },
  { to: "/events", label: "Events" },
  { to: "/plays", label: "Plays" },
  { to: "/sports", label: "Sports" },
  { to: "/monuments", label: "Monuments" },
  { to: "/international", label: "International" },
];
